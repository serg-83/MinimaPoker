# MinimaPoker — Game Guide

## Overview

MinimaPoker is a decentralized peer-to-peer Texas Hold'em poker game running as a MiniDAPP on the Minima blockchain. There is no central server — all game logic runs between players directly via the Maxima P2P messaging layer. Funds are secured by off-chain payment channels (eltoo protocol), so real Minima tokens are at stake without trusting any third party.

---

## Core Principles

### Decentralization
- No server, no house. Every player runs the game on their own Minima node.
- All messages (game actions, card commitments, channel updates) are sent peer-to-peer via Maxima.
- The blockchain is only touched when opening or closing a payment channel.

### Provably Fair Card Dealing (Commit-Reveal)
Cards are dealt using a cryptographic commit-reveal scheme so no single player can manipulate the deck:

1. **Commit phase** — each player generates a secret random hex string, hashes it (SHA3), and sends the hash to all others. Nobody can see the secret yet.
2. **Reveal phase** — each player reveals their secret. The game verifies each secret matches the previously sent hash.
3. **Seed combination** — all revealed secrets are XOR-combined into a single shared seed.
4. **Shuffle** — the 52-card deck is shuffled deterministically using that seed. The result is identical for all players.

This guarantees that no player could have predicted or influenced the card order.

### Payment Channels (Eltoo)
Chips are backed by real Minima tokens locked in an on-chain payment channel:

- The channel uses an **eltoo** (N-of-N multisig) mechanism — the same approach as the Thunder project.
- Every game action that changes chip counts produces a new **off-chain state update** signed by all players.
- The blockchain is only used to open (fund) and close (settle) the channel.
- If a player disappears or cheats, any participant can trigger a **dispute** — posting the trigger transaction on-chain and waiting for the settlement timeout.

---

## Game Flow

### 1. Lobby
- Players see each other's tables via Maxima contacts.
- **Create Table** — set max players (2–4), blinds (e.g. `10/20`), and buy-in amount (Minima per player, e.g. `1000`). The table is broadcast to all contacts.
- **Join Table** — navigate to an existing table.

### 2. Channel Creation (before first hand)
The table creator clicks **Create Channel**:
- A funding script (N-of-N multisig) and an eltoo script are generated and tracked on-chain.
- A `REQUEST_NEW_CHANNEL` message is sent to all players.
- Each player accepts → signs trigger and settlement transactions → sends back `REQUEST_ACCEPTED`.
- Creator assembles all signatures, signs the funding transaction, posts it on-chain.
- Channel status becomes **OPEN**.

### 3. Starting a Hand
Creator clicks **Start Game**:
- `GAME_START` message sent to all players with player list and blinds.
- Game enters **commit phase**.

### 4. Commit Phase
- Each player generates a 64-character hex secret locally.
- Computes SHA3(secret) → sends `COMMIT` message with the hash.
- When all commits received → game enters **reveal phase**.

### 5. Reveal Phase
- Each player sends `REVEAL` message with their original secret.
- Each secret is verified against the stored hash.
- If any secret is invalid → commit phase restarts.
- When all reveals valid → seeds combined → deck shuffled → hole cards dealt.

### 6. Betting Rounds
Standard Texas Hold'em structure:

| Round    | Community Cards | Action starts at       |
|----------|-----------------|------------------------|
| Pre-flop | none            | player after big blind |
| Flop     | 3 cards dealt   | player after dealer    |
| Turn     | 1 card dealt    | player after dealer    |
| River    | 1 card dealt    | player after dealer    |
| Showdown | —               | best hand wins the pot |

Available actions: **Fold**, **Check**, **Call**, **Raise**.

After each action that changes chip counts, a `SEND_FUNDS` message is sent to all players with new signed settlement and update transactions. All players countersign and reply with `REPLY_SEND_FUNDS`.

### 7. Showdown
- Active players reveal hole cards.
- Best 5-card hand from 2 hole + 5 community cards wins.
- Split pot on tie.
- Hand rankings (low to high): High Card, One Pair, Two Pair, Three of a Kind, Straight, Flush, Full House, Four of a Kind, Straight Flush.

### 8. Channel Close

**Cooperative close** — all players agree, a final spend transaction is signed by everyone and posted on-chain. Funds distributed immediately.

**Dispute (unilateral close)**:
- Any player can initiate a dispute, or it triggers automatically if a peer goes offline.
- The trigger transaction is posted on-chain (sequence = 0).
- After `MIN_UPDATE_COINAGE = 5 blocks` (~4 min) the latest update transaction is posted.
- After `MIN_SETTLE_COINAGE = 30 blocks` (~25 min) the settlement transaction is posted and funds distributed.
- Channel timeout: `50 blocks` (~42 min).

---

## Maxima Message Reference

All messages are JSON objects sent via `maxima.sendWithAck()`. The background service (`service.js`) handles them; the frontend (`table.js`, `lobby.js`) handles UI updates.

| Message                 | Sent by        | When                                          | Effect                                                          |
|-------------------------|----------------|-----------------------------------------------|-----------------------------------------------------------------|
| `TABLE_CREATE`          | Creator        | After creating a table                        | Inserts table into all contacts' databases; refreshes lobby     |
| `TABLE_DELETE`          | Creator        | After deleting a table                        | Removes table from all contacts' databases                      |
| `TABLE_JOIN`            | Joining player | When joining a table                          | Adds player to table's player list                              |
| `TABLE_LEAVE`           | Player         | When leaving a table                          | Removes player from table's player list                         |
| `REQUEST_NEW_CHANNEL`   | Creator        | After clicking Create Channel                 | Asks other players to accept channel creation                   |
| `REQUEST_ACCEPTED`      | Each player    | After accepting channel request               | Sends signed trigger + settlement txs back to creator           |
| `REQUEST_DENIED`        | Each player    | After rejecting channel request               | Notifies creator of refusal                                     |
| `CREATE_CHANNEL`        | Creator        | After collecting all acceptances              | Sends assembled funding + signed txs to all players             |
| `FINISH_START_CHANNEL`  | Each player    | After receiving CREATE_CHANNEL                | Signs funding tx, posts it on-chain; channel becomes OPEN       |
| `GAME_START`            | Creator        | After clicking Start Game                     | Initializes game state; starts commit phase                     |
| `COMMIT`                | Each player    | During commit phase                           | Sends SHA3 hash of secret to all players                        |
| `REVEAL`                | Each player    | During reveal phase                           | Sends original secret; verified against stored hash             |
| `BET`                   | Active player  | On fold / check / call / raise                | Sends action to all; triggers channel state update              |
| `SEND_FUNDS`            | State updater  | After each bet that changes balances          | Sends new signed settlement + update txs to all players         |
| `REPLY_SEND_FUNDS`      | Each player    | After receiving SEND_FUNDS                    | Countersigns and returns updated txs; state applied locally     |
| `SPEND_CHANNEL`         | Any player     | On cooperative close                          | Sends final spend tx for all to sign; posted on-chain           |
| `CHANNEL_CLOSE`         | Any player     | After channel is closed                       | Notifies all players to update channel status to CLOSED         |
| `DISPUTE`               | Any player     | On unilateral close / peer timeout            | Posts trigger tx on-chain; starts dispute timer                 |
| `LOBBY_CHAT`            | Any player     | When sending a message in lobby chat          | Broadcasts text message to all contacts                         |

---

## Database Tables

| Table            | Purpose                                                  |
|------------------|----------------------------------------------------------|
| `tables`         | Active poker tables (id, creator, blinds, buy-in, max players, state) |
| `players`        | Players at each table                                    |
| `channels`       | Payment channel state (txs, balances, status, sequence)  |
| `channel_states` | History of off-chain state updates                       |
| `game_states`    | Current game state per table (round, cards, pot, turn)   |
| `logs`           | Event log per channel (for debugging and dispute audit)  |

---

## Security Notes

- Secrets are generated locally with `utils.genRandomHexString(64)` — 256 bits of entropy.
- Commit hashes use SHA3 via Minima's `hash data:` command.
- All channel transactions require N-of-N signatures — no single player can steal funds.
- The eltoo mechanism ensures the latest state always wins on-chain, even if an old state is posted.
- Protocol version field (`protocolVersion: 1`) on all messages prevents cross-version interference.
