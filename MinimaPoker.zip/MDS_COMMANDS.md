# MinimaPoker — MDS Commands Reference

## MDS.cmd() — Wallet / Address

| Command | File | Description |
|---|---|---|
| `balance` | wallet.js, index.html | Get token balances |
| `newaddress` | wallet.js | Generate a new Minima address |
| `maxima;getaddress` | wallet.js | Get own Maxima pubkey + name + address |
| `maxima action:info` | index.html | Get own Maxima contact string (pubkey@host:port) |
| `maxima action:send to:... application:poker data:...` | maxima.js | Send P2P message via Maxima |
| `maxcontacts action:list` | index.html, lobby.js, service.js | List contacts |
| `maxcontacts action:add contact:...` | index.html | Add a contact |
| `maxcontacts action:remove id:...` | index.html | Remove a contact by id |

## MDS.cmd() — Signing / Tokens

| Command | File | Description |
|---|---|---|
| `sign publickey:... data:...` | wallet.js | Sign data with a key |
| `hash data:0x...` | crypto.js | SHA3 hash (used in commit-reveal) |
| `send address:... amount:... tokenid:...` | wallet.js | Send tokens (direct wallet transfer) |
| `tokens action:import data:...` | wallet.js | Import a custom token |

## MDS.cmd() — Channel Transactions (channel.js, wallet.js)
These are chained with `;` in a single MDS.cmd() call.

| Command | Description |
|---|---|
| `txncreate id:...` | Create a transaction in memory |
| `txninput id:... amount:... address:... floating:true` | Add input (floating = no specific coinid required) |
| `txnoutput id:... amount:... address:... storestate:true` | Add output |
| `txnstate id:... port:... value:...` | Set state variable (100=settlement flag, 101=sequence, 200=channel hashid) |
| `txnaddamount id:... tokenid:... amount:...` | Add funds from wallet (auto-selects coins) |
| `txnsign id:... publickey:...` | Sign transaction with a key |
| `txnimport id:... data:...` | Import a hex-encoded transaction |
| `txnexport id:...` | Export transaction to hex |
| `txnpost id:... auto:true` | Post transaction to the network |
| `txndelete id:...` | Delete transaction from memory |

## MDS.cmd() — Scripts / Blockchain

| Command | File | Description |
|---|---|---|
| `runscript script:"..."` | channel.js | Compute address of a KISSVM script |
| `newscript trackall:true script:"..."` | channel.js | Start tracking coins at a script address |
| `removescript address:...` | channel.js | Stop tracking a script address |
| `coins simplestate:true relevant:true` | service.js | Get all coins at tracked addresses |
| `block` | channel.js | Get current block height |

## MDS API (not MDS.cmd)

| Call | Where | Description |
|---|---|---|
| `MDS.init(callback)` | index.html, table.html, service.js | Initialize MDS, receive events (inited, NEWBLOCK, NEWCOIN, MAXIMA, MDSCOMMS) |
| `MDS.sql(query, callback)` | sql.js | Execute SQLite query |
| `MDS.log(msg)` | everywhere | Print message to Minima node log |
| `MDS.logging` | maxima.js | Boolean flag — whether MDS logging is enabled |
| `MDS.load(path)` | service.js | Load a JS module into the background service |
| `MDS.comms.solo(json)` | service.js | Send message from service to frontend (triggers MDSCOMMS event) |
| `MDS.filehost` | maxima.js | Base URL of the MiniDAPP (used to build asset URLs) |
| `MDS.minidappuid` | index.html, table.html | UID of this MiniDAPP instance (passed in URL params) |

## Fund Flow

```
Player wallet
    │
    │  txnaddamount (auto-selects coins from wallet)
    ▼
fundingAddress  ← N-of-N multisig script (buildFundingScript)
    │               computed via: runscript → address
    │               tracked via:  newscript trackall:true
    │
    │  trigger transaction (txnoutput → eltooAddress, sequence=0)
    ▼
eltooAddress    ← eltoo script (buildEltooScript, timeout=50 blocks)
    │               computed via: runscript → address
    │               tracked via:  newscript trackall:true
    │
    │  update transactions (sequence increases with each game state)
    │  settlement transaction (after timeout, distributes funds)
    ▼
participants[i].address  ← each player's regular Minima address (newaddress)
```

## Dispute Timeline

| Event | Blocks | Time (~50s/block) |
|---|---|---|
| Trigger tx posted on-chain | 0 | t=0 |
| Latest update tx posted | MIN_UPDATE_COINAGE = 5 | ~4 min |
| Settlement tx posted, funds distributed | MIN_SETTLE_COINAGE = 30 | ~25 min |
| Channel timeout | timeoutBlocks = 50 | ~42 min |

## Channel Scripts (KISSVM)

### fundingAddress — N-of-N multisig

```
LET randid=[<channelId>] ASSERT MULTISIG(N pubkey1 pubkey2 ...) RETURN TRUE
```

- Spendable only if **all** players have signed
- No timeout, no state variables
- Spent by: trigger transaction (channel open) or cooperative close transaction

---

### eltooAddress — eltoo update/settlement script

```
LET randid=[<channelId>]
LET settlement=STATE(100)
LET sequence=STATE(101)
LET prevsequence=PREVSTATE(101)
ASSERT MULTISIG(N pubkey1 pubkey2 ...)
IF settlement THEN
    IF sequence EQ prevsequence AND @COINAGE GTE <timeoutBlocks> THEN RETURN TRUE ENDIF
ELSE
    IF sequence GT prevsequence THEN RETURN TRUE ENDIF
ENDIF
```

| State variable | Port | Value | Meaning |
|---|---|---|---|
| `STATE(100)` | 100 | FALSE / TRUE | FALSE = update tx, TRUE = settlement tx |
| `STATE(101)` | 101 | integer | New sequence number |
| `PREVSTATE(101)` | 101 | integer | Sequence of the coin being spent |
| `STATE(200)` | 200 | channelId | Written to settlement outputs so the node can find its payout |

**Update transaction** (`STATE(100) = FALSE`):
- Passes if new sequence **> previous sequence**
- Replaces an old on-chain state with a newer one

**Settlement transaction** (`STATE(100) = TRUE`):
- Passes if sequence **== previous sequence** (this is the final state)
- AND coin age `@COINAGE >= timeoutBlocks` (default 50 blocks, ~42 min)
- Distributes funds to each participant's address

**Dispute flow:**
1. Trigger tx posted → eltooAddress coin appears with sequence = 0
2. After `MIN_UPDATE_COINAGE = 5 blocks` → latest update tx posted (bumps sequence to latest)
3. After `MIN_SETTLE_COINAGE = 30 blocks` → settlement tx posted → funds sent to players
